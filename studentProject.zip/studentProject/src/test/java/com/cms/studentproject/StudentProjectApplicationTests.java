package com.cms.studentproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
