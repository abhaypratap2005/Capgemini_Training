package com.cms.studentproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentProjectApplication {

    public static void main(String[] args) {

        SpringApplication.run(StudentProjectApplication.class, args);
    }

}
